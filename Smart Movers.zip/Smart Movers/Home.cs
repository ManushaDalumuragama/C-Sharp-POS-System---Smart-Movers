﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fahad
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void btnLd_Click(object sender, EventArgs e)
        {
            Load_details ld = new Load_details();
            this.Hide();
            ld.Show();
        }

        private void btnJd_Click(object sender, EventArgs e)
        {
            Jobs_details jd = new Jobs_details();
            this.Hide();
            jd.Show();
        }

        private void btnPd_Click(object sender, EventArgs e)
        {
            Product_details pd = new Product_details();
            this.Hide();
            pd.Show();
        }

        private void btnEd_Click(object sender, EventArgs e)
        {
            Employee_details ed = new Employee_details();
            this.Hide();
            ed.Show();
        }

        private void btnTud_Click(object sender, EventArgs e)
        {
            Transport_unit_details tud = new Transport_unit_details();
            this.Hide();
            tud.Show();
        }

        private void btnPayments_Click(object sender, EventArgs e)
        {
            Payment_details pd = new Payment_details();
            this.Hide();
            pd.Show();
        }

        private void btnDd_Click(object sender, EventArgs e)
        {
            Depot_details dd = new Depot_details();
            this.Hide();
            dd.Show();
        }

        private void btnCd_Click(object sender, EventArgs e)
        {
            Customer_details cd = new Customer_details();
            this.Hide();
            cd.Show();
        }

        private void btnLock_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }
    }
}
