﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fahad
{
    public partial class Customer_details : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=Manusha;Initial Catalog=smartmovers;Integrated Security=True");
        string cid, cids, fn, ln, addr, gen, nic;
        int ct, mn;

        public Customer_details()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string add = "insert into customer values ('" + cid + "','" + fn + "','" + ln + "','" + ct + "','" + addr + "','" + gen + "','" + nic + "','" + mn + "')";
                SqlCommand cmd = new SqlCommand(add, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer details added successfully!", "Customer details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string update = "update customer set fn = '" + fn + "', ln = '" + ln + "', ct = '" + ct + "', addr = '" + addr + "', gen = '" + gen + "', mn = '" + mn + "', nic = '" + nic + "' where cid = '" + cid + "' ";
                SqlCommand cmd = new SqlCommand(update, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer details updated successfully!", "Customer details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
           
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                cid = txtCid.Text;
                con.Open();
                string delete = "delete from customer where cid ='" + cid + "'";
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer details deleted successfully!", "Customer details", MessageBoxButtons.OK, MessageBoxIcon.None);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
           
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                cids = txtCids.Text;
                con.Open();
                string search = "select * from customer where cid ='" + cids + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                SqlDataReader read = cmd.ExecuteReader();
                while (read.Read())
                {
                    txtCid.Text = read["cid"].ToString();
                    txtFn.Text = read["fn"].ToString();
                    txtLn.Text = read["ln"].ToString();
                    cmbCt.Text = read["ct"].ToString();
                    txtAddress.Text = read["addr"].ToString();
                    if (read["gen"].ToString() == "Male")
                    {
                        rdbMale.Checked = true;
                    }
                    else
                    {
                        rdbFemale.Checked = true;
                    }
                    txtMn.Text = read["mn"].ToString();
                    txtNic.Text = read["nic"].ToString();
                }
                con.Close();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
           
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCid.Clear();
            txtCids.Clear();
            txtFn.Clear();
            txtLn.Clear();
            cmbCt.ResetText();
            txtAddress.Clear();
            rdbMale.Checked = false;
            rdbFemale.Checked = false;
            txtMn.Clear();
            txtNic.Clear();
            txtCid.Focus();
        }

        private void Clear()
        {
            txtCid.Clear();
            txtCids.Clear();
            txtFn.Clear();
            txtLn.Clear();
            cmbCt.ResetText();
            txtAddress.Clear();
            rdbMale.Checked = false;
            rdbFemale.Checked = false;
            txtMn.Clear();
            txtNic.Clear();
            txtCid.Focus();
        }

        private void LoadElement()
        {
            cid = txtCid.Text;
            cids = txtCids.Text;
            fn = txtFn.Text;
            ln = txtLn.Text;
            Int32.TryParse(cmbCt.Text, out ct);
            addr = txtAddress.Text;
            if (rdbMale.Checked==true)
            {
                gen = "Male";
            }
            else if (rdbFemale.Checked==true)
            {
                gen = "Female";
            }
            else
            {
                MessageBox.Show("Please select gender", "Gender", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Int32.TryParse(txtMn.Text, out mn);
            nic = txtNic.Text;
        }

        private void LoadGridView()
        {
            try
            {
                string query = "select * from customer";
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(query, con);
                DataSet ds = new DataSet();
                adapt.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
           
        }

        private void btnGth_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            this.Hide();
            home.Show();
        }

        private void btnLock_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void Customer_details_Load(object sender, EventArgs e)
        {

        }
    }
}
