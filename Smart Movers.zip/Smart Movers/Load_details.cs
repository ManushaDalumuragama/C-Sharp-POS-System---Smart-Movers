﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fahad
{
    public partial class Load_details : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=Manusha;Initial Catalog=smartmovers;Integrated Security=True");
        string lid, lt, lids, pid;
        DateTime ld;
        public Load_details()
        {
            InitializeComponent();
        }

        private void LoadElement()
        {
            lid = txtLid.Text;
            lids = txtLids.Text;
            lt = cmbLt.Text;
            ld = dtpDate.Value.Date;
            pid = txtPid.Text;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void clear()
        {
            txtLid.Clear();
            txtLids.Clear();
            cmbLt.ResetText();
            dtpDate.ResetText();
            txtPid.Clear();
            txtLid.Focus();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string query = "insert into load values ('" + lid + "','" + lt + "','" + ld + "','" + pid + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Load details added successfully!", "Load details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtLid.Clear();
            txtLids.Clear();
            cmbLt.ResetText();
            dtpDate.ResetText();
            txtPid.Clear();
            txtLid.Focus();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                lids = txtLids.Text;
                con.Open();
                string query = "select * from load where lid = '" + lids + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader read = cmd.ExecuteReader();
                while (read.Read())
                {
                    txtLid.Text = read["lid"].ToString();
                    cmbLt.Text = read["lt"].ToString();
                    dtpDate.Text = read["ld"].ToString();
                    txtPid.Text = read["pid"].ToString();
                }
                con.Close();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string query = "update load set lt = '" + lt + "', ld = '" + ld + "', pid = '" + pid + "' where lid = '" + lid + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Load details updated successfully!", "Load details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                clear();
                LoadGridView();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnGth_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            this.Hide();
            home.Show();
        }

        private void btnLock_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                lid = txtLid.Text;
                con.Open();
                string query = "delete from load where lid = '" + lid + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Load details deleted successfully!", "Load details", MessageBoxButtons.OK, MessageBoxIcon.None);
                con.Close();
                clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        private void LoadGridView()
        {
            try
            {
                string query = "select * from load";
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(query, con);
                DataSet ds = new DataSet();
                adapt.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close(); 
            }
        }
    }
}
