﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fahad
{
    public partial class Login : Form
    {
        string pw, un;
        public Login()
        {
            InitializeComponent();
        }

        private void Clear()
        {
            txtUn.Clear();
            txtPassword.Clear();
            txtUn.Focus();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {

            if (un == "smart" && pw == "smart123")
            {
                MessageBox.Show("Welcome to the Smartmovers!");
                Home home = new Home();
                this.Hide();
                home.Show();
            }
            else
            {
                MessageBox.Show("Username or password is incorrect", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Clear();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            un = txtUn.Text;
            pw = txtPassword.Text;
        }

        private void Login_Load(object sender, EventArgs e)
        {
            this.txtPassword.MaxLength = 8;
            this.txtPassword.PasswordChar = '*';
        }
    }
}
