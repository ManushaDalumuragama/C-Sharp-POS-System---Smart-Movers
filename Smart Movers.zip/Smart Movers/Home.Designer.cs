﻿namespace Fahad
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.label1 = new System.Windows.Forms.Label();
            this.btnPd = new System.Windows.Forms.Button();
            this.btnLd = new System.Windows.Forms.Button();
            this.btnEd = new System.Windows.Forms.Button();
            this.btnDd = new System.Windows.Forms.Button();
            this.btnPayments = new System.Windows.Forms.Button();
            this.btnTud = new System.Windows.Forms.Button();
            this.btnJd = new System.Windows.Forms.Button();
            this.btnCd = new System.Windows.Forms.Button();
            this.btnLock = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Stencil Std", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 43);
            this.label1.TabIndex = 48;
            this.label1.Text = "Home";
            // 
            // btnPd
            // 
            this.btnPd.BackColor = System.Drawing.Color.DimGray;
            this.btnPd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPd.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPd.ForeColor = System.Drawing.Color.White;
            this.btnPd.Location = new System.Drawing.Point(12, 83);
            this.btnPd.Name = "btnPd";
            this.btnPd.Size = new System.Drawing.Size(228, 104);
            this.btnPd.TabIndex = 1;
            this.btnPd.Text = "Product details";
            this.btnPd.UseVisualStyleBackColor = false;
            this.btnPd.Click += new System.EventHandler(this.btnPd_Click);
            // 
            // btnLd
            // 
            this.btnLd.BackColor = System.Drawing.Color.DimGray;
            this.btnLd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLd.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLd.ForeColor = System.Drawing.Color.White;
            this.btnLd.Location = new System.Drawing.Point(252, 83);
            this.btnLd.Name = "btnLd";
            this.btnLd.Size = new System.Drawing.Size(228, 104);
            this.btnLd.TabIndex = 2;
            this.btnLd.Text = "Load details";
            this.btnLd.UseVisualStyleBackColor = false;
            this.btnLd.Click += new System.EventHandler(this.btnLd_Click);
            // 
            // btnEd
            // 
            this.btnEd.BackColor = System.Drawing.Color.DimGray;
            this.btnEd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEd.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEd.ForeColor = System.Drawing.Color.White;
            this.btnEd.Location = new System.Drawing.Point(493, 83);
            this.btnEd.Name = "btnEd";
            this.btnEd.Size = new System.Drawing.Size(228, 104);
            this.btnEd.TabIndex = 3;
            this.btnEd.Text = "Employee details";
            this.btnEd.UseVisualStyleBackColor = false;
            this.btnEd.Click += new System.EventHandler(this.btnEd_Click);
            // 
            // btnDd
            // 
            this.btnDd.BackColor = System.Drawing.Color.DimGray;
            this.btnDd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDd.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDd.ForeColor = System.Drawing.Color.White;
            this.btnDd.Location = new System.Drawing.Point(493, 213);
            this.btnDd.Name = "btnDd";
            this.btnDd.Size = new System.Drawing.Size(228, 104);
            this.btnDd.TabIndex = 6;
            this.btnDd.Text = "Depot details";
            this.btnDd.UseVisualStyleBackColor = false;
            this.btnDd.Click += new System.EventHandler(this.btnDd_Click);
            // 
            // btnPayments
            // 
            this.btnPayments.BackColor = System.Drawing.Color.DimGray;
            this.btnPayments.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPayments.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPayments.ForeColor = System.Drawing.Color.White;
            this.btnPayments.Location = new System.Drawing.Point(252, 213);
            this.btnPayments.Name = "btnPayments";
            this.btnPayments.Size = new System.Drawing.Size(228, 104);
            this.btnPayments.TabIndex = 5;
            this.btnPayments.Text = "Payments";
            this.btnPayments.UseVisualStyleBackColor = false;
            this.btnPayments.Click += new System.EventHandler(this.btnPayments_Click);
            // 
            // btnTud
            // 
            this.btnTud.BackColor = System.Drawing.Color.DimGray;
            this.btnTud.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTud.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTud.ForeColor = System.Drawing.Color.White;
            this.btnTud.Location = new System.Drawing.Point(12, 213);
            this.btnTud.Name = "btnTud";
            this.btnTud.Size = new System.Drawing.Size(228, 104);
            this.btnTud.TabIndex = 4;
            this.btnTud.Text = "Transport unit details";
            this.btnTud.UseVisualStyleBackColor = false;
            this.btnTud.Click += new System.EventHandler(this.btnTud_Click);
            // 
            // btnJd
            // 
            this.btnJd.BackColor = System.Drawing.Color.DimGray;
            this.btnJd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJd.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJd.ForeColor = System.Drawing.Color.White;
            this.btnJd.Location = new System.Drawing.Point(252, 341);
            this.btnJd.Name = "btnJd";
            this.btnJd.Size = new System.Drawing.Size(228, 104);
            this.btnJd.TabIndex = 8;
            this.btnJd.Text = "Jobs details";
            this.btnJd.UseVisualStyleBackColor = false;
            this.btnJd.Click += new System.EventHandler(this.btnJd_Click);
            // 
            // btnCd
            // 
            this.btnCd.BackColor = System.Drawing.Color.DimGray;
            this.btnCd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCd.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCd.ForeColor = System.Drawing.Color.White;
            this.btnCd.Location = new System.Drawing.Point(12, 341);
            this.btnCd.Name = "btnCd";
            this.btnCd.Size = new System.Drawing.Size(228, 104);
            this.btnCd.TabIndex = 7;
            this.btnCd.Text = "Customer details";
            this.btnCd.UseVisualStyleBackColor = false;
            this.btnCd.Click += new System.EventHandler(this.btnCd_Click);
            // 
            // btnLock
            // 
            this.btnLock.BackColor = System.Drawing.Color.DimGray;
            this.btnLock.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLock.BackgroundImage")));
            this.btnLock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLock.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLock.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLock.ForeColor = System.Drawing.Color.White;
            this.btnLock.Location = new System.Drawing.Point(667, 12);
            this.btnLock.Name = "btnLock";
            this.btnLock.Size = new System.Drawing.Size(54, 49);
            this.btnLock.TabIndex = 9;
            this.btnLock.UseVisualStyleBackColor = false;
            this.btnLock.Click += new System.EventHandler(this.btnLock_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(733, 531);
            this.Controls.Add(this.btnLock);
            this.Controls.Add(this.btnJd);
            this.Controls.Add(this.btnCd);
            this.Controls.Add(this.btnDd);
            this.Controls.Add(this.btnPayments);
            this.Controls.Add(this.btnTud);
            this.Controls.Add(this.btnEd);
            this.Controls.Add(this.btnLd);
            this.Controls.Add(this.btnPd);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "Home";
            this.ShowIcon = false;
            this.Text = "Home";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPd;
        private System.Windows.Forms.Button btnLd;
        private System.Windows.Forms.Button btnEd;
        private System.Windows.Forms.Button btnDd;
        private System.Windows.Forms.Button btnPayments;
        private System.Windows.Forms.Button btnTud;
        private System.Windows.Forms.Button btnJd;
        private System.Windows.Forms.Button btnCd;
        private System.Windows.Forms.Button btnLock;
    }
}