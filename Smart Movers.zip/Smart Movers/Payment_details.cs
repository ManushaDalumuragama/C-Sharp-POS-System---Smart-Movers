﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fahad
{
    public partial class Payment_details : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=Manusha;Initial Catalog=smartmovers;Integrated Security=True");
        string pid, pids;
        int up, disc, tp;
        DateTime pd;
        public Payment_details()
        {
            InitializeComponent();
        }

        private void Clear()
        {
            txtPid.Clear();
            txtPids.Clear();
            dtpDate.ResetText();
            txtUp.Clear();
            txtDiscount.Clear();
            txtTp.Clear();
            txtPid.Focus();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPid.Clear();
            txtPids.Clear();
            dtpDate.ResetText();
            txtUp.Clear();
            txtDiscount.Clear();
            txtTp.Clear();
            txtPid.Focus();
        }

        private void LoadElement()
        {
            pid = txtPid.Text;
            pids = txtPids.Text;
            pd = dtpDate.Value.Date;
            Int32.TryParse(txtUp.Text, out up);
            Int32.TryParse(txtDiscount.Text, out disc);
            Int32.TryParse(txtTp.Text, out tp);

        }

        private void LoadGrideView()
        {
            try
            {
                string query = "select * from payment";
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(query, con);
                DataSet ds = new DataSet();
                adapt.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
         
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string add = "insert into payment values ('" + pid + "','" + pd + "','" + up + "','" + disc + "','" + tp + "')";
                SqlCommand cmd = new SqlCommand(add, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Payment details added successfully!", "Payment details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                Clear();
                LoadGrideView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string update = "update payment set pd = '" + pd + "', up = '" + up + "', disc = '" + disc + "', tp ='" + tp + "' where pid ='" + pid + "'";
                SqlCommand cmd = new SqlCommand(update, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Payment details updated successfully!", "Payment details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                Clear();
                LoadGrideView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
           
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                pid = txtPid.Text;
                con.Open();
                string delete = "delete from payment where pid = '" + pid + "'";
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Payment details deleted successfully!", "Payment details", MessageBoxButtons.OK, MessageBoxIcon.None);
                con.Close();
                Clear();
                LoadGrideView();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                pids = txtPids.Text;
                con.Open();
                string search = "select * from payment where pid = '" + pids + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                SqlDataReader read = cmd.ExecuteReader();
                while (read.Read())
                {
                    txtPid.Text = read["pid"].ToString();
                    dtpDate.Text = read["pd"].ToString();
                    txtUp.Text = read["up"].ToString();
                    txtDiscount.Text = read["disc"].ToString();
                    txtTp.Text = read["tp"].ToString();
                }
                con.Close();
                LoadGrideView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void txtDiscount_TextChanged(object sender, EventArgs e)
        {
            /*Int32.TryParse(txtUp.Text, out up);
            Int32.TryParse(txtDiscount.Text, out disc);

            tp = up - disc;
            txtTp.Text = tp.ToString();*/

            if (Int32.TryParse(txtUp.Text,out up) && Int32.TryParse(txtDiscount.Text, out disc))
            {
                txtTp.Text = (up - disc).ToString();
            }
        }

        private void btnGth_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            this.Hide();
            home.Show();
        }

        private void btnLock_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void Payment_details_Load(object sender, EventArgs e)
        {

        }
    }
}
