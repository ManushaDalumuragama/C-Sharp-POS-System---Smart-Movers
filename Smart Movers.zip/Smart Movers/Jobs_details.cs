﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fahad
{
    public partial class Jobs_details : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=Manusha;Initial Catalog=smartmovers;Integrated Security=True");
        string jid, name, jt, jids;
        public Jobs_details()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtJid.Clear();
            txtJids.Clear();
            txtName.Clear();
            cmbJt.ResetText();
            txtJid.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                LoadElement();
                string query = "insert into jobs values ('" + jid + "','" + name + "','" + jt + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Jobs details added successfully!", "Jobs details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void LoadGridView()
        {
            try
            {
                string query = "select * from jobs";
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(query, con);
                DataSet ds = new DataSet();
                adapt.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void clear()
        {
            txtJid.Clear();
            txtJids.Clear();
            txtName.Clear();
            cmbJt.ResetText();
            txtJid.Focus();
        }

        private void LoadElement()
        {
            jid = txtJid.Text;
            jids = txtJids.Text;
            name = txtName.Text;
            jt = cmbJt.Text;
        }

        private void btnGth_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            this.Hide();
            home.Show();
        }

        private void btnLock_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string query = "update jobs set name = '" + name + "', jt = '" + jt + "' where jid = '"+jid+"'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Jobs details updated successfully!", "Job details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                jid = txtJid.Text;
                con.Open();
                string query = "delete from jobs where jid = '" + jid + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Jobs details delete successfully!", "Jobs details", MessageBoxButtons.OK, MessageBoxIcon.None);
                con.Close();
                clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                jids = txtJids.Text;
                con.Open();
                string query = "select * from jobs where jid = '" + jids + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader read = cmd.ExecuteReader();
                while (read.Read())
                {
                    txtJid.Text = read["jid"].ToString();
                    txtName.Text = read["name"].ToString();
                    cmbJt.Text = read["jt"].ToString();
                }
                con.Close();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

            }
            
        }
        
    }

