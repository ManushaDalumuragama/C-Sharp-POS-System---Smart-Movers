﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fahad
{
    public partial class Depot_details : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=Manusha;Initial Catalog=smartmovers;Integrated Security=True");
        string did, dids, loca;
        public Depot_details()
        {
            InitializeComponent();
        }

        private void Clear()
        {
            txtDid.Clear();
            txtDids.Clear();
            txtLocation.Clear();
            txtDid.Focus();
        }

        private void LoadElement()
        {
            did = txtDid.Text;
            dids = txtDids.Text;
            loca = txtLocation.Text;
        }

        private void LoadGridView()
        {
            try
            {
                string query = "select * from depot";
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(query, con);
                DataSet ds = new DataSet();
                adapt.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
          
        }

        private void btnGth_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            this.Hide();
            home.Show();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDid.Clear();
            txtDids.Clear();
            txtLocation.Clear();
            txtDid.Focus();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string add = "insert into depot values ('" + did + "','" + loca + "')";
                SqlCommand cmd = new SqlCommand(add, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Depot details added successfully!", "Depot details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string update = "update depot set loca = '" + loca + "' where did = '" + did + "'";
                SqlCommand cmd = new SqlCommand(update, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Depot details updated successfully!", "Depot details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
           
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                did = txtDid.Text;
                con.Open();
                string delete = "delete from depot where did = '" + did + "'";
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Depot details deleted successfully!", "Depot details", MessageBoxButtons.OK, MessageBoxIcon.None);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                dids = txtDids.Text;
                con.Open();
                string search = "select * from depot where did = '" + dids + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                SqlDataReader read = cmd.ExecuteReader();
                while (read.Read())
                {
                    txtDid.Text = read["did"].ToString();
                    txtLocation.Text = read["loca"].ToString();
                }
                con.Close();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
           
        }

        private void btnLock_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void Depot_details_Load(object sender, EventArgs e)
        {

        }
    }
}
