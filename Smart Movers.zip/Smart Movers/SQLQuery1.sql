create database smartmovers
use smartmovers

create table customer
(cid varchar (10) primary key,
fn varchar (30) not null,
ln varchar (40) not null,
ct int check (ct<4) not null,
addr varchar (300) not null,
gen varchar (6) not null,
nic varchar (10) not null unique,
mn int not null unique)

create table payment
(pid varchar (10) primary key,
pd date not null,
up int not null,
disc int not null,
tp int not null)

create table product
(pid varchar (10) primary key,
pn varchar (30) not null unique,
bn varchar (30) not null,
pt varchar (10) not null,
quan int not null,
price int not null)

create table employee
(eid varchar (10) primary key,
fn varchar (30) not null,
ln varchar (30) not null,
jt varchar (15) not null,
addr varchar (300) not null,
gen varchar (6) not null,
mn int not null unique,
nic varchar (10) not null unique,
dob date not null,
sala int not null)

create table jobs
(jid varchar (10) primary key,
name varchar (30) not null,
jt varchar (15) not null)

create table load
(lid varchar (10) primary key,
lt varchar (15) not null,
ld date not null,
pid varchar (10) foreign key references payment (pid) on update cascade on delete cascade)

create table depot
(did varchar (10) primary key,
loca varchar (20) not null)

create table transport
(tid varchar (10) primary key,
lorry varchar (10) not null,
cont varchar (10) not null)

select * from load

insert into employee (eid,fn,ln,jt,addr,gen,mn,nic,dob,sala)
values ('E004','Ramanayaka','Suresh','Supporter','Mawathagama, Welihinda, Denipitiya','Male','0771237678','952565300v','1995-10-05','70000')

delete from customer where cid = 'C001'

select * from employee where sala between 60000 and 80000

select count (eid), fn from employee group by fn

select count (cid), ct from customer group by ct having count (ct)>1

update employee set fn = 'Niresh' where eid = 'E001'

select count (eid), fn from employee group by fn order by COUNT (eid)

alter table load add pid varchar (10) foreign key references payment(pid)

drop table load


select load.*, payment. * from load,payment
