﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fahad
{
    public partial class Product_details : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=Manusha;Initial Catalog=smartmovers;Integrated Security=True");
        string pid, pids, pn, bn, pt;
        int quan, price;

        public Product_details()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPid.Clear();
            txtPids.Clear();
            txtPn.Clear();
            txtBn.Clear();
            cmbPt.ResetText();
            txtQuantity.Clear();
            txtPrice.Clear();
            txtPid.Focus();
        }

        private void btnGth_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            this.Hide();
            home.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string query = "insert into product values ('" + pid + "','" + pn + "','" + bn + "','" + pt + "','" + quan + "','" + price + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product details added successfully!", "Product details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string query = "update product set pn = '" + pn + "', bn = '" + bn + "', pt = '" + pt + "', quan = '" + quan + "', price = '" + price + "' where pid = '" + pid + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product details updated successfully!", "Product details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                pid = txtPid.Text;
                con.Open();
                string query = "delete from product where pid = '" + pid + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product details deleted successfully!", "Product details", MessageBoxButtons.OK, MessageBoxIcon.None);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnLock_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                pids = txtPids.Text;
                con.Open();
                string query = "select * from product where pid = '" +pids+ "'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader read = cmd.ExecuteReader();
                while (read.Read())
                {
                    txtPid.Text = read["pid"].ToString();
                    txtPn.Text = read["pn"].ToString();
                    txtBn.Text = read["bn"].ToString();
                    cmbPt.Text = read["pt"].ToString();
                    txtQuantity.Text = read["quan"].ToString();
                    txtPrice.Text = read["price"].ToString();
                }
                con.Close();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void LoadElement()
        {
            pid = txtPid.Text;
            pids = txtPids.Text;
            pn = txtPn.Text;
            bn = txtBn.Text;
            pt = cmbPt.Text;
            Int32.TryParse(txtQuantity.Text, out quan);
            Int32.TryParse(txtPrice.Text, out price);
        }

        private void Clear()
        {
            txtPid.Clear();
            txtPids.Clear();
            txtPn.Clear();
            txtBn.Clear();
            cmbPt.ResetText();
            txtQuantity.Clear();
            txtPrice.Clear();
            txtPid.Focus();
        }

        private void LoadGridView()
        {
            try
            {
                string query = "select * from product";
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(query, con);
                DataSet ds = new DataSet();
                adapt.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void Product_details_Load(object sender, EventArgs e)
        {

        }
    }
}
