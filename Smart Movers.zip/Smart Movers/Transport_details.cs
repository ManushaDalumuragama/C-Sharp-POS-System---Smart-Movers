﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fahad
{
    public partial class Transport_unit_details : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=Manusha;Initial Catalog=smartmovers;Integrated Security=True");
        string tid, tids, lorry, cont;
        public Transport_unit_details()
        {
            InitializeComponent();
        }

        private void Clear()
        {
            txtTid.Clear();
            txtTids.Clear();
            txtLorry.Clear();
            txtContainer.Clear();
            txtTid.Focus();
        }

        private void LoadElement()
        {
            tid = txtTid.Text;
            tids = txtTids.Text;
            lorry = txtLorry.Text;
            cont = txtContainer.Text;
        }

        private void LoadGridView()
        {
            try
            {
                string query = "select * from transport";
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(query, con);
                DataSet ds = new DataSet();
                adapt.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
           
        }

        private void btnGth_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            this.Hide();
            home.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string add = "insert into transport values ('" + tid + "','" + lorry + "','" + cont + "')";
                SqlCommand cmd = new SqlCommand(add, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Transport unit details added successfully!", "Transport details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string update = "update transport set lorry = '" + lorry + "', cont = '" + cont + "' where tid = '" + tid + "'";
                SqlCommand cmd = new SqlCommand(update, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Transport details updated successfully!", "Transport details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                tid = txtTid.Text;
                con.Open();
                string delete = "delete from transport where tid = '" + tid + "'";
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Transport details deleted successfully!", "Transport details", MessageBoxButtons.OK, MessageBoxIcon.None);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                tids = txtTids.Text;
                con.Open();
                string search = "select * from transport where tid ='" + tids + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                SqlDataReader read = cmd.ExecuteReader();
                while (read.Read())
                {
                    txtTid.Text = read["tid"].ToString();
                    txtLorry.Text = read["Lorry"].ToString();
                    txtContainer.Text = read["cont"].ToString();
                }
                con.Close();
                LoadGridView();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }


        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtTid.Clear();
            txtTids.Clear();
            txtLorry.Clear();
            txtContainer.Clear();
            txtTid.Focus();
        }

        private void btnLock_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void Transport_unit_details_Load(object sender, EventArgs e)
        {

        }
    }
}
