﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fahad
{
    public partial class Employee_details : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=Manusha;Initial Catalog=smartmovers;Integrated Security=True");
        string eid, eids, fn, ln, jt, addr, gen, nic;
        int mn, sala;

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEid.Clear();
            txtEids.Clear();
            txtFn.Clear();
            txtLn.Clear();
            cmbJt.ResetText();
            txtAddress.Clear();
            rdbMale.Checked = false;
            rdbFemale.Checked = false;
            dtpDate.ResetText();
            txtMn.Clear();
            txtNic.Clear();
            txtSalary.Clear();
            txtEid.Focus();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string add = "insert into employee values ('" + eid + "','" + fn + "','" + ln + "','" + jt + "','" + addr + "','" + gen + "','" + mn + "','" + nic + "','" + dob + "','" + sala + "')";
                SqlCommand cmd = new SqlCommand(add, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee details added successfully!", "Employee details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                LoadElement();
                con.Open();
                string update = "update employee set fn = '" + fn + "', ln = '" + ln + "', jt = '" + jt + "', addr = '" + addr + "', gen = '" + gen + "', dob = '" + dob + "', mn = '" + mn + "', nic = '" + nic + "', sala = '" + sala + "' where eid = '" + eid + "'";
                SqlCommand cmd = new SqlCommand(update, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee details updated successfully!", "Employee details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                eid = txtEid.Text;
                con.Open();
                string delete = "delete from employee where eid = '" + eid + "'";
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee details deleted successfully!", "Employee details", MessageBoxButtons.OK, MessageBoxIcon.None);
                con.Close();
                Clear();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                eids = txtEids.Text;
                con.Open();
                string search = "select * from employee where eid = '" + eids + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                SqlDataReader read = cmd.ExecuteReader();
                while (read.Read())
                {
                    txtEid.Text = read["eid"].ToString();
                    txtFn.Text = read["fn"].ToString();
                    txtLn.Text = read["ln"].ToString();
                    cmbJt.Text = read["jt"].ToString();
                    txtAddress.Text = read["addr"].ToString();
                    if(read["gen"].ToString() == "Male")
                    {
                        rdbMale.Checked = true;
                    }
                    else
                    {
                        rdbFemale.Checked = true;
                    }
                    dtpDate.Text = read["dob"].ToString();
                    txtMn.Text = read["mn"].ToString();
                    txtNic.Text = read["nic"].ToString();
                    txtSalary.Text = read["sala"].ToString();
                }
                con.Close();
                LoadGridView();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void LoadGridView()
        {
            try
            {
                string query = "select * from employee";
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(query, con);
                DataSet ds = new DataSet();
                adapt.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            
        }

        DateTime dob;
        public Employee_details()
        {
            InitializeComponent();
        }

        private void LoadElement()
        {
            eid = txtEid.Text;
            eids = txtEids.Text;
            fn = txtFn.Text;
            ln = txtLn.Text;
            jt = cmbJt.Text;
            addr = txtAddress.Text;
            if (rdbMale.Checked == true)
            {
                gen = "Male";
            }
            else if (rdbFemale.Checked == true)
            {
                gen = "Female";
            }
            else
            {
                MessageBox.Show("Please select gender", "Gender", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Int32.TryParse(txtMn.Text, out mn);
            nic = txtNic.Text;
            dob = dtpDate.Value.Date;
            Int32.TryParse(txtSalary.Text, out sala);
        }

        private void Clear()
        {
            txtEid.Clear();
            txtEids.Clear();
            txtFn.Clear();
            txtLn.Clear();
            cmbJt.ResetText();
            txtAddress.Clear();
            rdbMale.Checked = false;
            rdbFemale.Checked = false;
            dtpDate.ResetText();
            txtMn.Clear();
            txtNic.Clear();
            txtSalary.Clear();
            txtEid.Focus();
        }

        private void btnGth_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            this.Hide();
            home.Show();
        }

        private void btnLock_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void Employee_details_Load(object sender, EventArgs e)
        {

        }
    }
}
